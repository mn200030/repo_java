package com.test;

public class Reserve {
    public Integer accountId;
    public Integer storeId;
    public String message;
    public Long reserveTime;
}
